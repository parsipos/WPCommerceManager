package ir.woocommerceyar.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Credentials
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class WooApi {
    private val client = OkHttpClient.Builder().connectTimeout(12, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(false).build()
    private fun endpoint(store: Store, resource: String): String = "${store.url.trimEnd('/')}/wp-json/wc/v3/$resource"
    private suspend fun request(store: Store, resource: String, method: String = "GET", body: JSONObject? = null): String = withContext(Dispatchers.IO) {
        val builder = Request.Builder().url(endpoint(store, resource))
            .header("Authorization", Credentials.basic(store.key, store.secret))
            .header("Accept", "application/json")
        if (method == "PUT") builder.put(requireNotNull(body).toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
        client.newCall(builder.build()).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException("HTTP ${response.code}: ${text.take(220)}")
            text
        }
    }
    suspend fun verify(s: Store) { request(s, "orders?per_page=1") }
    suspend fun orders(s: Store): JSONArray = JSONArray(request(s, "orders?per_page=50&orderby=date&order=desc"))
    suspend fun products(s: Store): JSONArray = JSONArray(request(s, "products?per_page=50"))
    suspend fun updateOrder(s: Store, id: Long, status: String): JSONObject = JSONObject(request(s, "orders/$id", "PUT", JSONObject().put("status", status)))
}
