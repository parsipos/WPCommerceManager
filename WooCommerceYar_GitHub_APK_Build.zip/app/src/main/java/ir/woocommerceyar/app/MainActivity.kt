package ir.woocommerceyar.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repository = StoreRepository(this)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF3458A4))) {
                    WooApp(repository)
                }
            }
        }
    }
}

@Composable
fun WooApp(repository: StoreRepository) {
    val api = remember { WooApi() }
    val scope = rememberCoroutineScope()
    var stores by remember { mutableStateOf(repository.read()) }
    var selected by remember { mutableStateOf(stores.firstOrNull()?.id) }
    var tab by remember { mutableStateOf("داشبورد") }
    var adding by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var orders by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var products by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    val store = stores.find { it.id == selected }
    fun refresh(s: Store) {
        scope.launch {
            busy = true; error = ""; orders = emptyList(); products = emptyList()
            try {
                orders = api.orders(s).objects()
                products = api.products(s).objects()
            } catch (e: Exception) { error = "دریافت اطلاعات ناموفق بود: ${e.message.orEmpty().take(180)}" }
            finally { busy = false }
        }
    }
    LaunchedEffect(selected) { store?.let { refresh(it) } }
    Scaffold(topBar = {
        Surface(color = MaterialTheme.colorScheme.primary) {
            Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("ووکامرس‌یار", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                TextButton(onClick = { adding = true }) { Text("+ فروشگاه", color = MaterialTheme.colorScheme.onPrimary) }
            }
        }
    }, bottomBar = {
        NavigationBar {
            listOf("داشبورد", "سفارش‌ها", "محصولات", "فروشگاه‌ها").forEach { t ->
                NavigationBarItem(selected = tab == t, onClick = { tab = t }, icon = { Text(when(t) { "داشبورد" -> "▦"; "سفارش‌ها" -> "▤"; "محصولات" -> "▣"; else -> "⌂" }) }, label = { Text(t) })
            }
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (store != null && tab != "فروشگاه‌ها") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("فروشگاه: ${store.name}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { refresh(store) }) { Text("به‌روزرسانی") }
                }
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
            when (tab) {
                "فروشگاه‌ها" -> {
                    Text("فروشگاه‌های متصل", style = MaterialTheme.typography.titleLarge)
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(stores, key = { it.id }) { s ->
                            ElevatedCard(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(s.name, fontWeight = FontWeight.Bold)
                                    Text(s.url, style = MaterialTheme.typography.bodySmall)
                                    Row {
                                        TextButton(onClick = { selected = s.id; tab = "داشبورد" }) { Text("انتخاب") }
                                        TextButton(onClick = { val updated = stores.filterNot { it.id == s.id }; repository.write(updated); stores = updated; if (selected == s.id) selected = updated.firstOrNull()?.id }) { Text("حذف") }
                                    }
                                }
                            }
                        }
                    }
                }
                "داشبورد" -> if (store == null) Text("برای شروع یک فروشگاه اضافه کنید.") else {
                    Text("خلاصه ۵۰ سفارش اخیر", style = MaterialTheme.typography.titleLarge)
                    val sum = orders.sumOf { it.optString("total").toDoubleOrNull() ?: 0.0 }
                    SummaryTile("تعداد سفارش‌های دریافت‌شده", orders.size.toString())
                    SummaryTile("جمع مبلغ سفارش‌های دریافت‌شده", "${"%,.0f".format(sum)} ${orders.firstOrNull()?.optString("currency") ?: ""}")
                    Text("این آمار فقط بر اساس ۵۰ سفارش اخیر است و گزارش مالی کل فروشگاه محسوب نمی‌شود.", style = MaterialTheme.typography.bodySmall)
                }
                "سفارش‌ها" -> if (store == null) Text("ابتدا فروشگاه انتخاب کنید.") else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(orders, key = { it.optLong("id") }) { order ->
                        var expanded by remember { mutableStateOf(false) }
                        ElevatedCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("سفارش #${order.optLong("id")}", fontWeight = FontWeight.Bold)
                                val billing = order.optJSONObject("billing")
                                Text("${billing?.optString("first_name").orEmpty()} ${billing?.optString("last_name").orEmpty()}")
                                Text("${order.optString("total")} ${order.optString("currency")} | ${order.optString("status")}")
                                Text("تاریخ: ${order.optString("date_created")}")
                                TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "بستن" else "جزئیات و تغییر وضعیت") }
                                if (expanded) {
                                    Text("موبایل: ${billing?.optString("phone").orEmpty()}")
                                    val lines = order.optJSONArray("line_items") ?: JSONArray()
                                    for (i in 0 until lines.length()) {
                                        val line = lines.optJSONObject(i) ?: continue
                                        Text("${line.optString("name")} × ${line.optInt("quantity")}")
                                    }
                                    listOf("processing" to "در حال انجام", "completed" to "تکمیل‌شده", "on-hold" to "در انتظار", "cancelled" to "لغوشده").forEach { (status, label) ->
                                        OutlinedButton(enabled = !busy, onClick = {
                                            scope.launch {
                                                busy = true; error = ""
                                                try { api.updateOrder(store, order.optLong("id"), status); orders = api.orders(store).objects() }
                                                catch (e: Exception) { error = "تغییر وضعیت ناموفق بود: ${e.message}" }
                                                finally { busy = false }
                                            }
                                        }) { Text(label) }
                                    }
                                }
                            }
                        }
                    }
                }
                "محصولات" -> if (store == null) Text("ابتدا فروشگاه انتخاب کنید.") else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(products, key = { it.optLong("id") }) { p ->
                        ElevatedCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text(p.optString("name"), fontWeight = FontWeight.Bold)
                                Text("قیمت: ${p.optString("price")} | موجودی: ${if(p.isNull("stock_quantity")) "نامشخص" else p.optString("stock_quantity")}")
                                Text("وضعیت: ${p.optString("status")}")
                            }
                        }
                    }
                }
            }
        }
    }
    if (adding) AddStoreDialog(onDismiss = { adding = false }, onSave = { name, url, key, secret ->
        val s = Store(UUID.randomUUID().toString(), name.trim(), url.trim().trimEnd('/'), key.trim(), secret.trim())
        scope.launch {
            busy = true; error = ""
            try {
                api.verify(s)
                val updated = stores + s
                repository.write(updated); stores = updated; selected = s.id; tab = "داشبورد"; adding = false
            } catch (e: Exception) { error = "اتصال برقرار نشد: ${e.message.orEmpty().take(180)}"; adding = false }
            finally { busy = false }
        }
    })
}

@Composable
private fun SummaryTile(title: String, value: String) {
    ElevatedCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun AddStoreDialog(onDismiss: () -> Unit, onSave: (String, String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var secret by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("افزودن فروشگاه") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("نام فروشگاه") }, singleLine = true)
            OutlinedTextField(url, { url = it }, label = { Text("آدرس HTTPS فروشگاه") }, placeholder = { Text("https://example.com") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
            OutlinedTextField(key, { key = it }, label = { Text("Consumer Key") }, singleLine = true)
            OutlinedTextField(secret, { secret = it }, label = { Text("Consumer Secret") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
            Text("کلیدهای API باید مجوز خواندن و نوشتن داشته باشند.", style = MaterialTheme.typography.bodySmall)
        }
    }, confirmButton = {
        TextButton(enabled = name.isNotBlank() && url.startsWith("https://") && key.startsWith("ck_") && secret.startsWith("cs_"), onClick = { onSave(name, url, key, secret) }) { Text("بررسی و اتصال") }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}

private fun JSONArray.objects(): List<JSONObject> = (0 until length()).mapNotNull { optJSONObject(it) }
