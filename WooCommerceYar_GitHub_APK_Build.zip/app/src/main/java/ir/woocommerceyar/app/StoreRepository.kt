package ir.woocommerceyar.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class Store(val id: String, val name: String, val url: String, val key: String, val secret: String)

class StoreRepository(context: Context) {
    private val prefs = context.getSharedPreferences("stores_v1", Context.MODE_PRIVATE)
    private val alias = "woocommerceyar_stores_aes"
    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build())
        }.generateKey()
    }
    fun read(): List<Store> = try {
        val raw = prefs.getString("payload", null) ?: ""
        if (raw.isEmpty()) emptyList() else {
        val bytes = Base64.decode(raw, Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, bytes.copyOfRange(0, 12)))
        val array = JSONArray(String(cipher.doFinal(bytes.copyOfRange(12, bytes.size)), Charsets.UTF_8))
        (0 until array.length()).map { i -> array.getJSONObject(i).let { Store(it.getString("id"), it.getString("name"), it.getString("url"), it.getString("key"), it.getString("secret")) } }
        }
    } catch (_: Exception) { emptyList() }
    fun write(stores: List<Store>) {
        val arr = JSONArray()
        stores.forEach { s -> arr.put(JSONObject().put("id", s.id).put("name", s.name).put("url", s.url).put("key", s.key).put("secret", s.secret)) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val data = cipher.iv + cipher.doFinal(arr.toString().toByteArray(Charsets.UTF_8))
        check(prefs.edit().putString("payload", Base64.encodeToString(data, Base64.NO_WRAP)).commit())
    }
}
